﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void uploadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                panel1.Controls.Clear();
                FrmEmployees r = new FrmEmployees();
                r.TopLevel = false;
                r.Dock = DockStyle.Fill;
                r.FormBorderStyle = FormBorderStyle.None;
                r.WindowState = FormWindowState.Maximized;
                this.panel1.Controls.Add(r);
                r.Show();
                //FrmEmployees f = new FrmEmployees();
                //f.ShowDialog();
            }
            catch { }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string message = cc.Logoff(Mainform.username);
            }
            catch { }

            Application.Exit();
        }

        private void downloadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            Customer r = new Customer();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel1.Controls.Add(r);
            r.Show();
            //Customer c = new Customer();
            //c.ShowDialog();
        }

        private void purchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            Purchase r = new Purchase();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel1.Controls.Add(r);
            r.Show();
            //Purchase p = new Purchase();
            //p.ShowDialog();
        }

        private void salesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            VendorDetails r = new VendorDetails();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel1.Controls.Add(r);
            r.Show();
            //VendorDetails s = new VendorDetails();
            //s.ShowDialog();
        }

        private void uploadToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           
        }

        private void downloadToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void displayFilesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            DisplayFiles r = new DisplayFiles();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel1.Controls.Add(r);
            r.Show();
           
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            Help r = new Help();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel1.Controls.Add(r);
            r.Show();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string message = cc.Logoff(Mainform.username);
            }
            catch { }           
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string message = cc.Logoff(Mainform.username);
            }
            catch { }

            Application.Exit();
        }
    }
}
