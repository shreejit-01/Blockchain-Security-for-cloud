﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class AdminUpload : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();
        string filename = "";
        public AdminUpload()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog op = new OpenFileDialog();
                if (op.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = op.FileName;
                    filename = op.FileName;
                }               
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string checkuser = "";
            foreach (object itemChecked in checkedListBox1.CheckedItems)
            {
                checkuser += itemChecked.ToString() + ",";
            }

            if (checkuser == "") { MessageBox.Show("Select Users"); }
            else
            {
                try
                {
                    string fname = Path.GetFileName(filename);

                    string per = ""; string per1 = ""; string per2 = "";
                    if (checkBox1.Checked == true)
                    {
                        per = "read";
                    }

                    if (checkBox2.Checked == true)
                    {
                        per1 = "write";
                    }

                    per2 = per + "," + per1;

                    string result = cc.AdminFile_Upload(fname, checkuser,per2);
                    if (File.Exists(Application.StartupPath + "//AdminUpload//" + fname)) { }
                    else
                    {
                        File.Copy(filename, Application.StartupPath + "//AdminUpload//" + fname);
                    }

                    if (result == "File Uploaded Successfully..!!")
                    {
                        MessageBox.Show("File Uploaded Successfully");
                    }
                }
                catch { }
            }

            try
            {
                cc.Log("Admin", "File Upload : " + filename, "AdminUpload", DateTime.Now.ToString());
            }
            catch { }
        }

        private void AdminUpload_Load(object sender, EventArgs e)
        {
            try
            {
               
                string[] ccc = cc.UserList().Split('~');

                for (int i = 0; i < ccc.Length; i++)
                {
                    checkedListBox1.Items.Insert(0, ccc[i].ToString());
                }
            
            }
            catch { }
        }
    }
}
