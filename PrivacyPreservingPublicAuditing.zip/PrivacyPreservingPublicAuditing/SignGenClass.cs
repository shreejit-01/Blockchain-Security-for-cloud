﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace PrivacyPreservingPublicAuditing
{
    [Serializable()]
    class SignGenClass:ISerializable
    {
        public long filesize;
        public string Username;
        public string signs;
        public string filename;
        public long multipliers;
        
        public SignGenClass()
        {
            filesize = 0;
            Username = null;
            signs = "";
            filename = null;
        }

        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            //You can use any custom name for your name-value pair. But make sure you
            // read the values with the same name. For ex:- If you write EmpId as "EmployeeId"
            // then you should read the same with "EmployeeId"
            info.AddValue("Username", Username);
            info.AddValue("filename", filename);
            info.AddValue("sign", signs);
            info.AddValue("filesize", filesize);
        }

        public SignGenClass(SerializationInfo info, StreamingContext ctxt)
        {
            //Get the values from info and assign them to the appropriate properties
            filename = (String)info.GetValue("filename", typeof(string));
            signs = (String)info.GetValue("sign", typeof(string));
        }
    }
}
