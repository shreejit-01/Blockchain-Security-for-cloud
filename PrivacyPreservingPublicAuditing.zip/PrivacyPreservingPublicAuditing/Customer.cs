﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using GDataDB;
using GDataDB.Linq;
using System.Data.SqlClient;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Customer : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();

        SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");
        string[,] data = new string[20, 10];
        string[,] data1 = new string[20, 10];
        public static string key = "cryptographyStegnography"; //Secret key(public key)
        public static byte[] input_file = new byte[1024 * 1000];//Length of file(no of characters in the file)
        private static string _b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk.mnopqrstuvwxyz-123456789+/=";
        apis.Lead opp = new apis.Lead();
        string did = "";

        public Customer()
        {
            InitializeComponent();
        }

        public void clear()
        {
            txtadd.Text = "";
            txtCity.Text = "";
            txtcode.Text = "";
            txtCountry.Text = "";
            txtdesgn.Text = "";
            txtemailid.Text = "";
            txtname.Text = "";
            txtphno.Text = "";
            txtState.Text = "";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string code = txtcode.Text;
                string name = txtname.Text;
                string address = txtadd.Text;
                string city = txtCity.Text;
                string state = txtState.Text;
                string country = txtCountry.Text;
                string dob = dateTimePickerDateOfBirth.Text;
                string email = txtemailid.Text;
                string phone = txtphno.Text;
                string designation = txtdesgn.Text;
               


             
                string message = cc.Customer(code,name,address,city,state,country,email,dob,designation,phone);
                MessageBox.Show(message);

              
                cc.Log(Mainform.username, "Upload", "Customer", DateTime.Now.ToString());
            }
            catch { }
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string[] res = cc.GetCustomer().ToString().Split('~');

                dataGridView1.Rows.Clear();

                for (int i = 0; i < res.Length; i++)
                {
                    if (res[i] == "") { }
                    else
                    {
                        string[] data = res[i].ToString().Split(',');
                        dataGridView1.Rows.Add();
                        for (int j = 0; j < data.Length; j++)
                        {
                            dataGridView1.Rows[i].Cells[j].Value = data[j].ToString();
                        }
                    }

                }
            }
            catch { }

            try
            {
                cc.Log(Mainform.username, "Retrieve", "Customer", DateTime.Now.ToString());
            }
            catch { }
        }

        private void txtcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txtphno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txtname_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtState_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtCity_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtCountry_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtdesgn_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void Customer_Load(object sender, EventArgs e)
        {
            if (Mainform.adminflg == 1)
            {
                btnRetrieve_Click(null, null);
            }
            else
            {
                btnsave.Visible = false;
                btnRetrieve.Visible = false;

                try
                {
                    //blockchain.BlockChain cc = new blockchain.BlockChain();
                    //string result = cc.GetAuthentication("Customer", Mainform.username);

                    //string[] data = result.ToString().Split(',');


                     int flg = 0;
                    List<string> udetails = new List<string>();                

                    if (File.Exists(Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt"))
                    {
                        flg = 1;
                    }

                    if (flg > 0)
                    {
                        string files = Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt";
                        StreamReader sr = new StreamReader(files);
                        string[] data1 = sr.ReadToEnd().ToString().Split('~');
                        sr.Close();

                        AES a = new AES("00");
                        for (int i = 0; i < data1.Length; i++)
                        {
                            string textt = a.Decrypt_CBC(data1[i].ToString());
                            udetails.Add(textt);
                        }


                        udetails[3] = udetails[3].Replace("Customer Permission : ", "");
                        string[] data = udetails[3].ToString().Split(',');

                        if (data.Length == 1)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[0].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }

                        }

                        else if (data.Length == 2)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[1].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Block Not Present");
                    }
                }
                catch { }
            }
        }

    }
}
