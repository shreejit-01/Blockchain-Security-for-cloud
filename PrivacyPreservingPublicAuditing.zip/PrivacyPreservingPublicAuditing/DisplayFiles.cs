﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class DisplayFiles : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();
        public DisplayFiles()
        {
            InitializeComponent();
        }

        private void DisplayFiles_Load(object sender, EventArgs e)
        {
            try
            {
                string username = Mainform.username.ToString();
                string filename = cc.displayfiles(username);
                string[] spfile = filename.ToString().Split('~');
                for (int i = 0; i < spfile.Length; i++)
                {
                    if (spfile[i] == "") { }
                    else
                    {
                        listBox1.Items.Add(spfile[i].ToString());
                    }
                }
            }
            catch { }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string[] per = cc.ReadWritefile(listBox1.SelectedItem.ToString()).Split(',');                
                string fname = Application.StartupPath + "\\AdminUpload\\" + listBox1.SelectedItem.ToString();
                if (per[0].ToString().Trim().ToLower() == "read".ToString().Trim().ToLower())
                {
                    StreamReader sr = new StreamReader(fname);
                    string data = sr.ReadToEnd().ToString();
                    sr.Close();

                    textBox1.Text = data.ToString();
                    textBox1.Enabled = false;
                    button1.Enabled = false;
                    //System.Diagnostics.Process.Start(fname);
                }               
                    
                if (per[1].ToString().Trim().ToLower() == "write".ToString().Trim().ToLower())
                {
                    textBox1.Enabled = true;
                    button1.Enabled = true;
                    //System.Diagnostics.Process.Start(fname);
                }               
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                try
                {
                    if (File.Exists(Application.StartupPath + "\\AdminUpload\\" + listBox1.SelectedItem.ToString()))
                    {
                        File.Delete(Application.StartupPath + "\\AdminUpload\\" + listBox1.SelectedItem.ToString());
                    }
                }
                catch { }

                StreamWriter sw = new StreamWriter(Application.StartupPath + "\\AdminUpload\\" + listBox1.SelectedItem.ToString());
                sw.WriteLine(textBox1.Text);
                sw.Close();
                MessageBox.Show("Data Successfully Saved..!!");
            }
            catch { }
        }
    }
}
