﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Login : Form
    {
        public static apis.LoginResult lr = null;
        public static int login_flag = 0;
        public static string username = "";
         public static string mobileno = "";
        public static int randomotp = 0;
        SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");
        public static String user = null;
        public static String pass = null;

        public Login()
        {
            InitializeComponent();
        }

        public void clear()
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                blockchain.BlockChain bb = new blockchain.BlockChain();
                String msg = bb.BlockLogin(Mainform.username);

                if (msg == "Success")
                {
                    int flg = 0;
                    if (File.Exists(Application.StartupPath + "\\BlockHeader\\" + textBox1.Text + ".txt"))
                    {
                        flg = 1;
                    }

                    if (flg > 0)
                    {
                        string files = Application.StartupPath + "\\BlockHeader\\" + textBox1.Text + ".txt";
                        StreamReader sr = new StreamReader(files);
                        string[] data = sr.ReadToEnd().ToString().Split('~');
                        sr.Close();
                        AES a = new AES("00");

                        for (int i = 0; i < data.Length; i++)
                        {
                            string textt = a.Decrypt_CBC(data[i].ToString());
                        }

                        blockchain.BlockChain cc = new blockchain.BlockChain();
                        string message = cc.BlockChain_Login(textBox1.Text, textBox2.Text);

                        if (message == "Success")
                        {
                            try
                            {
                                cc.Log(username, "Login", "Login", DateTime.Now.ToString());
                            }
                            catch { }

                            username = textBox1.Text;
                            Main m = new Main();
                            this.Hide();
                            m.Show();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect User Name or Password..");
                            textBox2.Text = "";
                            textBox1.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Block Not Present..You cant't Login");
                    }
                }
                else
                {
                    MessageBox.Show("Login Failed");
                }
            }
            catch
            {             
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mainform m = new Mainform();
            this.Hide();
            m.ShowDialog();
            //Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Registration r = new Registration();
            this.Hide();
            r.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            randomotp = r.Next(1000, 9000);

            try
            {
                System.Net.WebClient client = new WebClient();
                string message = "Your One Time Password is :" + randomotp + " \nfor  Login \n\nThanks\n\n .";

                string baseurl = "http://msg.msgclub.net/rest/services/sendSMS/v2/sendGroupSms?AUTH_KEY=c0d0db8bdc9d33758222d6d44ad1bb9d&message=" + message + "&senderId=MNASIK&routeId=1&mobileNos=" + (mobileno).Trim() + "&smsContentType=english";

                Stream data = client.OpenRead(baseurl);
                StreamReader reader = new StreamReader(data);
                string s = reader.ReadToEnd();
                

            }
            catch {  }

                
           

        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            DataSet ds = new DataSet();
            user = textBox1.Text;
            pass = textBox2.Text;
            SqlDataAdapter sda = new SqlDataAdapter("select UserName, Password,Mobile from DecentralisedAccess where UserName='" + user + "' and Password='" + pass + "' ", con);
            sda.Fill(ds);
            int cnt = ds.Tables[0].Rows.Count;
            if (cnt < 1)
            {
                MessageBox.Show("No Records Found");
                clear();
            }
            else
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    user = ds.Tables[0].Rows[i][0].ToString();
                    pass = ds.Tables[0].Rows[i][1].ToString();
                    mobileno = ds.Tables[0].Rows[i][2].ToString();
                }
            }
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
