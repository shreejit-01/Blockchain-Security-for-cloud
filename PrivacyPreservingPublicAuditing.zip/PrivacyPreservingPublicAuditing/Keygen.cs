﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
namespace PrivacyPreservingPublicAuditing
{

    [Serializable()]
    class Keygen : ISerializable
    {
        public long filesize;
        public string Username;
        public long keys;
        public string filename;
        public long multipliers;


        public Keygen()
        {
            filesize = 0;
            Username = null;
            keys = 0;
            filename = null;
            //multipliers =null ;
        }

        //Serialization function.
        public void GetObjectData(SerializationInfo info, StreamingContext ctxt)
        {
            //You can use any custom name for your name-value pair. But make sure you
            // read the values with the same name. For ex:- If you write EmpId as "EmployeeId"
            // then you should read the same with "EmployeeId"
            info.AddValue("Username", Username);
            info.AddValue("filename", filename);
            info.AddValue("keys", keys);
            info.AddValue("filesize", filesize);


        }
        public Keygen(SerializationInfo info, StreamingContext ctxt)
        {
            //Get the values from info and assign them to the appropriate properties
            Username = (String)info.GetValue("Username", typeof(string));
            keys = (long)info.GetValue("keys", typeof(long));

        }
    }
}
