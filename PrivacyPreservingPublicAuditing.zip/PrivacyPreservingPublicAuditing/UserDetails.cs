﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class UserDetails : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();
        public UserDetails()
        {
            InitializeComponent();
        }

        private void UserDetails_Load(object sender, EventArgs e)
        {
            try
            {
                dataGridView1.Rows.Clear();            
                string[] list = cc.ApproveByAdmin1().Split('~');
                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i] == "") { }
                    else
                    {
                        string[] list1 = list[i].ToString().Split(',');
                        dataGridView1.Rows.Add();
                        dataGridView1.Rows[i].Cells[0].Value = list1[0].ToString();
                        dataGridView1.Rows[i].Cells[1].Value = list1[1].ToString();
                        dataGridView1.Rows[i].Cells[2].Value = list1[2].ToString();
                        dataGridView1.Rows[i].Cells[3].Value = list1[3].ToString();
                        dataGridView1.Rows[i].Cells[4].Value = list1[4].ToString();
                        dataGridView1.Rows[i].Cells[5].Value = list1[5].ToString();
                        dataGridView1.Rows[i].Cells[6].Value = list1[6].ToString();
                        dataGridView1.Rows[i].Cells[7].Value = list1[7].ToString();
                        dataGridView1.Rows[i].Cells[8].Value = list1[8].ToString();
                        dataGridView1.Rows[i].Cells[9].Value = list1[9].ToString();

                        if (list1[11].ToString() == "0")
                        {
                            dataGridView1.Rows[i].Cells[10].Value = "Inactive".ToString();
                        }
                        else if (list1[11].ToString() == "1")
                        {
                            dataGridView1.Rows[i].Cells[10].Value = "Active".ToString();
                        }                       
                    }
                }                
            }
            catch { }

            try
            {
                GenerateBlockChain();
            }
            catch { }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 11)
            {
                string adminname = "admin1";
                string username = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                string res = cc.UpdateLcount(adminname,username);

                if (res == "Record Updated Successfully..!!")
                {
                    MessageBox.Show("Record Successfully Updated");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Record Not Updated");
                }

                cc.Log("Admin1", "admin", "UserDetails", DateTime.Now.ToString());

                try
                {
                    GenerateBlockChain();
                }
                catch { }
            }

            if (e.ColumnIndex == 12)
            {
               // string adminname = "admin1";
                string username = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                string res = cc.DeactiveAdmin2(username);

                if (res == "Success")
                {
                    MessageBox.Show("User Inactive Successfully");
                    LoadGrid();
                }
                else
                {
                    MessageBox.Show("Failed");
                }

                cc.Log("Admin2", "admin", "Admin2 Inactive User " + username, DateTime.Now.ToString());
            }
        }


        public void LoadGrid()
        {
            try
            {
                dataGridView1.Rows.Clear();
                string[] list = cc.ApproveByAdmin1().Split('~');
                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i] == "") { }
                    else
                    {
                        string[] list1 = list[i].ToString().Split(',');
                        dataGridView1.Rows.Add();
                        dataGridView1.Rows[i].Cells[0].Value = list1[0].ToString();
                        dataGridView1.Rows[i].Cells[1].Value = list1[1].ToString();
                        dataGridView1.Rows[i].Cells[2].Value = list1[2].ToString();
                        dataGridView1.Rows[i].Cells[3].Value = list1[3].ToString();
                        dataGridView1.Rows[i].Cells[4].Value = list1[4].ToString();
                        dataGridView1.Rows[i].Cells[5].Value = list1[5].ToString();
                        dataGridView1.Rows[i].Cells[6].Value = list1[6].ToString();
                        dataGridView1.Rows[i].Cells[7].Value = list1[7].ToString();
                        dataGridView1.Rows[i].Cells[8].Value = list1[8].ToString();
                        dataGridView1.Rows[i].Cells[9].Value = list1[9].ToString();

                        if (list1[11].ToString() == "0")
                        {
                            dataGridView1.Rows[i].Cells[10].Value = "Inactive".ToString();
                        }
                        else if (list1[11].ToString() == "1")
                        {
                            dataGridView1.Rows[i].Cells[10].Value = "Active".ToString();
                        }
                    }
                }
            }
            catch { }        
        }



        public void GenerateBlockChain()
        {
            AES aa = new AES("00");
            try
            {
                string[] uname = cc.UserList().Split('~');
                for (int i = 0; i < uname.Length; i++)
                {                  

                    StreamWriter sw = new StreamWriter(Application.StartupPath + "\\BlockHeader\\" + uname[i].ToString() + ".txt");
                    string encryptdata = "";
                    string[] data = cc.GenerateBlockHeader(uname[i].ToString()).Split('~');

                    for (int j = 0; j < data.Length; j++)
                    {
                        string encrypt = aa.Encrypt_CBC(data[j].ToString());

                        if (j == 0)
                        {
                            encryptdata = encrypt.ToString();
                        }
                        else
                        {
                            encryptdata += "~" + encrypt.ToString();
                        }
                    }
                    sw.WriteLine(encryptdata);
                    sw.Close();
                }
            }
            catch { }
        }
    }
}
