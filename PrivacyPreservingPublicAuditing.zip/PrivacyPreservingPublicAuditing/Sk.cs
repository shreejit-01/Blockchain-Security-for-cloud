﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Sk : Form
    {
        public static String k = null;
        
        public Sk()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                k = textBox1.Text;
                MessageBox.Show("Key Submitted");
                this.Close();
                Cursor.Current = Cursors.Default;
            }
            catch
            {

            }
        }
    }
}
