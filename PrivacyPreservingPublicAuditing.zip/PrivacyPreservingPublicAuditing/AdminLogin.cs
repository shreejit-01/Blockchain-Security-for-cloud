﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrivacyPreservingPublicAuditing
{
    public partial class AdminLogin : Form
    {
        public static int adminflg = 0;
        
        public AdminLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_username.Text == "admin" && txt_password.Text == "pass")
                {
                    try
                    {
                        blockchain.BlockChain cc = new blockchain.BlockChain();
                        cc.Log("Admin", "Login", "AdminLogin", DateTime.Now.ToString());
                    }
                    catch { }
                    
                    adminflg = 1;
                    //Authentication m = new Authentication();                  
                    Admin_Mainform m = new Admin_Mainform();                  
                    m.ShowDialog();
                    this.Close();

                    
                }
                else
                {
                    MessageBox.Show("Incorrect User Name or Password");
                    txt_password.Text = "";
                    txt_username.Text = "";

                }
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mainform m = new Mainform();
            this.Hide();
            m.ShowDialog();
        }

        private void AdminLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
