﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using GDataDB;
using GDataDB.Linq;

namespace PrivacyPreservingPublicAuditing
{
    public partial class FrmEmployees : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();
        SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");
        string[,] data = new string[20, 10];
        string[,] data1 = new string[20, 10];
        public static string key = "cryptographyStegnography"; //Secret key(public key)
        public static byte[] input_file = new byte[1024 * 1000];//Length of file(no of characters in the file)
        private static string _b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk.mnopqrstuvwxyz-123456789+/=";
        apis.Lead opp = new apis.Lead();
        string did = "";

        public FrmEmployees()
        {
            InitializeComponent();
        }

        public void clear()
        {
            txtadd.Text = "";
            txtCity.Text = "";
            txtcode.Text = "";
            txtCountry.Text = "";
            txtdesgn.Text = "";
            txtemailid.Text = "";
            txtname.Text = "";
            txtphno.Text = "";
            txtState.Text = "";
        }
        
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtphno_Leave(object sender, EventArgs e)
        {          
            if (txtphno.Text.Length > 10 || txtphno.Text.Length < 10)
            {
                MessageBox.Show("Enter Valid Phone Number");
            }
        }

        private void txtemailid_Leave(object sender, EventArgs e)
        {
            if (txtemailid.Text.Contains('@') == true && txtemailid.Text.Contains('@') == true)
            {

            }
            else
            {
                MessageBox.Show("Enter Proper Mail Id");
            }
        }

        private void txtcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txtphno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
           
        }
        
        private void txtState_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtCity_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtCountry_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txtdesgn_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string code = txtcode.Text;
                string name = txtname.Text;
                string address = txtadd.Text;
                string city = txtCity.Text;
                string state = txtState.Text;
                string country = txtCountry.Text;
                string dob = dateTimePickerDateOfBirth.Text;
                string email = txtemailid.Text;
                string phone = txtphno.Text;
                string designation = txtdesgn.Text;               

                string message = cc.Employee(code, name, address, city, state, country, email, dob, designation, phone);
                MessageBox.Show(message);

                cc.Log(Mainform.username, "Upload", "Employee", DateTime.Now.ToString());
            }
            catch { }
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string[] res = cc.GetEmployee().ToString().Split('~');

                Datagridview1.Rows.Clear();

                for (int i = 0; i < res.Length; i++)
                {
                    if (res[i] == "") { }
                    else
                    {
                        string[] data = res[i].ToString().Split(',');
                        Datagridview1.Rows.Add();
                        for (int j = 0; j < data.Length; j++)
                        {
                            Datagridview1.Rows[i].Cells[j].Value = data[j].ToString();
                        }
                    }

                }
            }
            catch { }

            try
            {
                cc.Log(Mainform.username, "Retrieve", "Employee", DateTime.Now.ToString());
            }
            catch { }
        }

        private void FrmEmployees_Load(object sender, EventArgs e)
        {
            if (Mainform.adminflg == 1)
            {
                btnRetrieve_Click(null, null);
            }
            else
            {
                btnsave.Visible = false;
                btnRetrieve.Visible = false;

                try
                {
                    int flg = 0;
                    List<string> udetails = new List<string>();
                    //blockchain.BlockChain cc = new blockchain.BlockChain();
                    //string result = cc.GetAuthentication("Employee", Mainform.username);

                    if (File.Exists(Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt"))
                    {
                        flg = 1;
                    }

                    if (flg > 0)
                    {
                        string files = Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt";
                        StreamReader sr = new StreamReader(files);
                        string[] data1 = sr.ReadToEnd().ToString().Split('~');
                        sr.Close();

                        AES a = new AES("00");

                        for (int i = 0; i < data1.Length; i++)
                        {
                            string textt = a.Decrypt_CBC(data1[i].ToString());
                            udetails.Add(textt);
                        }

                        udetails[2] = udetails[2].Replace("Employee Permission : ", "");

                        //  string[] data = result.ToString().Split(',');
                        string[] data = udetails[2].ToString().Split(',');
                        if (data.Length == 1)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[0].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }
                        }

                        else if (data.Length == 2)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[1].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Block Not Present");
                    }
                }
                catch { }
            }
        }       
    }
}
