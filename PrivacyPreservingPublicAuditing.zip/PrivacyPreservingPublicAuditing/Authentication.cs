﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Authentication : Form
    {
        public Authentication()
        {
            InitializeComponent();
        }

        private void Authentication_Load(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string message = cc.UserList();

                listBox1.Items.Clear();

                string[] data = message.ToString().Split('~');
                for (int i = 0; i < data.Length; i++)
                {
                    listBox1.Items.Add(data[i].ToString());
                }


                    //MessageBox.Show(message);
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                string username = "";
                try
                {
                    foreach (var item in listBox1.SelectedItems)
                    {
                        username = item.ToString();
                    }
                }
                catch { }

                if (username == "")
                {
                    MessageBox.Show("Select User ");
                }
                else
                {
                    try
                    {
                        string Employee = "";
                        if (checkBox1.Checked == true)
                        {
                            Employee = "Upload" + ",";
                        }
                        if (checkBox2.Checked == true)
                        {
                            Employee += "Retrieve";
                        }

                        string Customer = "";
                        if (checkBox4.Checked == true)
                        {
                            Customer = "Upload" + ",";
                        }
                        if (checkBox3.Checked == true)
                        {
                            Customer += "Retrieve";
                        }

                        string Purchase = "";
                        if (checkBox6.Checked == true)
                        {
                            Purchase = "Upload" + ",";
                        }
                        if (checkBox5.Checked == true)
                        {
                            Purchase += "Retrieve";
                        }

                        string Vendor = "";
                        if (checkBox8.Checked == true)
                        {
                            Vendor = "Upload" + ",";
                        }
                        if (checkBox7.Checked == true)
                        {
                            Vendor += "Retrieve";
                        }


                        blockchain.BlockChain cc = new blockchain.BlockChain();
                        string result = cc.BlockChain_Authentication(username, Employee, Customer, Purchase, Vendor);
                        MessageBox.Show(result);

                        cc.Log("Admin", "Authentication", "Authentication", DateTime.Now.ToString());

                        try
                        {
                            StreamReader sr = new StreamReader(Application.StartupPath + "//BlockHeader//" + listBox1.SelectedItem + ".txt");
                            string[] data = sr.ReadToEnd().ToString().Split('~');
                            sr.Close();

                            AES aa = new AES("00");
                            //string text = "";
                            //for (int i = 0; i < data.Length; i++)
                            //{
                            //    text += aa.Decrypt_CBC(data[i].ToString())+",";
                            //}

                            string emppermission = aa.Encrypt_CBC("Employee Permission : " + Employee);
                            string custpermission = aa.Encrypt_CBC("Customer Permission : " + Customer);
                            string purpermission = aa.Encrypt_CBC("Purchase Permission : " + Purchase);
                            string venpermission = aa.Encrypt_CBC("Vendor Permission : " + Vendor);

                            if (File.Exists(Application.StartupPath + "//BlockHeader//" + listBox1.SelectedItem + ".txt"))
                            {
                                File.Delete(Application.StartupPath + "//BlockHeader//" + listBox1.SelectedItem + ".txt");
                            }

                            StreamWriter sw = new StreamWriter(Application.StartupPath + "//BlockHeader//" + listBox1.SelectedItem + ".txt");
                            sw.Write(data[0] + "~" + data[1] + "~" + emppermission + "~" + custpermission + "~" + purpermission + "~" + venpermission + "~" + data[6] + "~" + data[7]);
                            sw.Close();

                        }
                        catch { }
                    }
                    catch { }
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mainform m = new Mainform();
            this.Hide();
            m.ShowDialog();
          
        }
    }
}
