﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Mainform : Form
    {
        public static string adminname = "";
        public static int adminflg = 0;

        public static apis.LoginResult lr = null;
        public static int login_flag = 0;
        public static string username = "";
        public static string mobileno = "";
        public static int randomotp = 0;
       // SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");
        public static String user = null;
        public static String pass = null;

        public Mainform()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                AdminLogin l = new AdminLogin();
                this.Hide();
                l.ShowDialog();
              
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Login l = new Login();
                this.Hide();
                l.ShowDialog();
               
            }
            catch { }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Select")
            {
                MessageBox.Show("Select Admin");
            }
            else
            {
                try
                {
                    if (txt_username.Text == "admin" && txt_password.Text == "pass")
                    {
                        try
                        {
                            adminname = "admin 1";
                            blockchain.BlockChain cc = new blockchain.BlockChain();
                            cc.Log("Admin", "Login", "AdminLogin", DateTime.Now.ToString());
                        }
                        catch { }

                        adminflg = 1;
                        Admin_Mainform m = new Admin_Mainform();
                        m.ShowDialog();
                        this.Close();
                    }
                    else if (txt_username.Text == "admin" && txt_password.Text == "123")
                    {
                        try
                        {
                            adminname = "admin 2";
                            blockchain.BlockChain cc = new blockchain.BlockChain();
                            cc.Log("Admin", "Login", "AdminLogin", DateTime.Now.ToString());
                        }
                        catch { }

                        adminflg = 1;
                        Admin_Mainform m = new Admin_Mainform();
                        m.ShowDialog();
                        this.Close();
                    }
                    else if (txt_username.Text == "admin" && txt_password.Text == "147")
                    {
                        try
                        {
                            adminname = "admin 3";
                            blockchain.BlockChain cc = new blockchain.BlockChain();
                            cc.Log("Admin", "Login", "AdminLogin", DateTime.Now.ToString());
                        }
                        catch { }

                        adminflg = 1;
                        Admin_Mainform m = new Admin_Mainform();
                        m.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Incorrect User Name or Password");
                        txt_password.Text = "";
                        txt_username.Text = "";
                    }
                }
                catch { }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Registration r = new Registration();
           // this.Hide();
            r.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain bb = new blockchain.BlockChain();
                String msg = bb.BlockLogin(textBox1.Text);

                if (msg == "Success")
                {

                    int flg = 0;
                    if (File.Exists(Application.StartupPath + "\\BlockHeader\\" + textBox1.Text + ".txt"))
                    {
                        flg = 1;
                    }

                    if (flg > 0)
                    {
                        string files = Application.StartupPath + "\\BlockHeader\\" + textBox1.Text + ".txt";
                        StreamReader sr = new StreamReader(files);
                        string[] data = sr.ReadToEnd().ToString().Split('~');
                        sr.Close();
                        AES a = new AES("00");

                        List<string> udetails = new List<string>();

                        for (int i = 0; i < data.Length; i++)
                        {
                            string textt = a.Decrypt_CBC(data[i].ToString());
                            udetails.Add(textt);
                        }

                        blockchain.BlockChain cc = new blockchain.BlockChain();
                        string message = cc.BlockChain_Login(textBox1.Text, textBox2.Text);

                        if (message == "Success")
                        {
                            try
                            {
                                cc.Log(username, "Login", "Login", DateTime.Now.ToString());
                            }
                            catch { }

                            username = textBox1.Text;
                            Main m = new Main();
                            this.Hide();
                            m.Show();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect User Name or Password..");
                            textBox2.Text = "";
                            textBox1.Text = "";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Block Not Present..You cant't Login");
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Login");
                }
            }
            catch
            {
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void Mainform_Load(object sender, EventArgs e)
        {

        }
    }
}
