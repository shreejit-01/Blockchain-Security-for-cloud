﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Registration : Form
    {
        SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");

        public Registration()
        {
            InitializeComponent();
        }

        public void clear()
        {
            txtAddress.Text = "";
            txtConfirmPassword.Text = "";
            txtEmail.Text = "";
            txtMobile.Text = "";
            txtName.Text = "";
            txtPassword.Text = "";
            txtPhone.Text = "";
            txtUsername.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                // Check for All Feilds Data is Proper
                if (txtName.Text == "" || txtAddress.Text == "" || txtMobile.Text == "" || txtPhone.Text == "" || dtpDOB.Text == "" || txtEmail.Text == "" || txtUsername.Text == "" || txtEmail.Text.Contains('@') == false || txtEmail.Text.Contains('.') == false || txtPassword.Text == "" || txtConfirmPassword.Text == "")
                {
                    MessageBox.Show("Enter Proper Data");
                    clear();
                }
                else
                {
                    blockchain.BlockChain cc = new blockchain.BlockChain();
                    string message = cc.BlockChain_Registration(txtName.Text, txtAddress.Text, txtMobile.Text, txtPhone.Text, dtpDOB.Text, txtEmail.Text, txtUsername.Text, txtPassword.Text, txtConfirmPassword.Text, "0", "0", "0", "0");

                    MessageBox.Show(message);

                    try
                    {
                        cc.Log(txtUsername.Text, "Registration", "Registration", DateTime.Now.ToString());

                    }
                    catch { }                    //// Generating Keys 
                    //string pk = null; // this is public key PK
                    //string sk = null;  // this is private key SK

                    //// Register Code 
                    //con.Open();
                    //SqlCommand cmd = new SqlCommand("insert into DecentralisedAccess values('" + txtName.Text + "','" + txtAddress.Text + "','" + txtMobile.Text + "','" + txtPhone.Text + "','" + dtpDOB.Text + "','" + txtEmail.Text + "','" + txtUsername.Text + "','" + txtPassword.Text + "','" + txtConfirmPassword.Text + "','" + pk + "','" + sk + "')", con);
                    //cmd.ExecuteNonQuery();
                    //MessageBox.Show("Registration Completed");
                    //clear();
                    //con.Close();
                }
                Cursor.Current = Cursors.Default;
            }
            catch
            {
                con.Close();
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void txtMobile_Leave(object sender, EventArgs e)
        {
            if (txtMobile.Text.Length > 10 || txtMobile.Text.Length < 10)
            {
                MessageBox.Show("Enter Valid Phone Number");
                txtMobile.Text = "";
            }
        }

        private void txtPhone_Leave(object sender, EventArgs e)
        {
            if (txtPhone.Text.Length > 10 || txtPhone.Text.Length < 10)
            {
                MessageBox.Show("Enter Valid Phone Number");
                txtPhone.Text = "";
            }
        }

        private void txtConfirmPassword_Leave(object sender, EventArgs e)
        {
            String pass, cpass;
            pass = txtPassword.Text;
            cpass = txtConfirmPassword.Text;
            if (pass == cpass)
            {

            }
            else
            {
                MessageBox.Show("Password Not Match");
            }
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txtMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txtName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }
    }
}
