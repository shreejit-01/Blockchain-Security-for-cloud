﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrivacyPreservingPublicAuditing
{
    public partial class DisplayLog : Form
    {
        public DisplayLog()
        {
            InitializeComponent();
        }

        private void DisplayLog_Load(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string[] data = cc.DisplayLog().Split('~');
                for (int i = 0; i < data.Length; i++)
                {
                    string[] data1 = data[i].ToString().Split(',');
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells[0].Value = data1[0].ToString();
                    dataGridView1.Rows[i].Cells[1].Value = data1[1].ToString();
                    dataGridView1.Rows[i].Cells[2].Value = data1[2].ToString();
                    dataGridView1.Rows[i].Cells[3].Value = data1[3].ToString();
                    dataGridView1.Rows[i].Cells[4].Value = data1[4].ToString();
                }
            }
            catch { }
        }
    }
}
