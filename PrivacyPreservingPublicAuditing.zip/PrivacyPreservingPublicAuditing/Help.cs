﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Help : Form
    {
        public Help()
        {
            InitializeComponent();
        }

        private void Help_Load(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr = new StreamReader(Application.StartupPath+"\\Help.txt");
                string data = sr.ReadToEnd().ToString();
                sr.Close();

                richTextBox1.Text = data.ToString();
            }
            catch { }
        }
    }
}
