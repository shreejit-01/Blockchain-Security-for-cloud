﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Text.RegularExpressions;
using System.IO;
using System.Data.SqlClient;

namespace PrivacyPreservingPublicAuditing
{
    public partial class VendorDetails : Form
    {
        blockchain.BlockChain cc = new blockchain.BlockChain();
        SqlConnection con = new SqlConnection("Data Source=64.71.180.27;User ID=opass_123;Password=pass_123");
        string[,] data = new string[20, 10];
        string[,] data1 = new string[20, 10];
        public static string key = "cryptographyStegnography"; //Secret key(public key)
        public static byte[] input_file = new byte[1024 * 1000];//Length of file(no of characters in the file)
        private static string _b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk.mnopqrstuvwxyz-123456789+/=";
        apis.Case opp = new apis.Case();
        string did = "";

        public VendorDetails()
        {
            InitializeComponent();
        }

        private void txt_vname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txt_city_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txt_State_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txt_pincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txt_description_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                  && !char.IsLetter(e.KeyChar)
                 && e.KeyChar != '.' && e.KeyChar != '_' && e.KeyChar != '-' && e.KeyChar != '/')
            {
                e.Handled = true;
            }
        }

        private void txt_country_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txt_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txt_vattinno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        private void txt_cstno_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar)
                && !char.IsDigit(e.KeyChar)
             )
            {
                e.Handled = true;
            }
        }

        public void clear()
        {
            txt_address.Text = "";
            txt_city.Text = "";
            txt_country.Text = "";
            txt_cstno.Text = "";
            txt_description.Text = "";
            txt_email.Text = "";
            txt_phone.Text = "";
            txt_pincode.Text = "";
            txt_State.Text = "";
            txt_vattinno.Text = "";
            txt_vname.Text = "";
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                string vendorname = txt_vname.Text;
                string address = txt_address.Text;
                string city = txt_city.Text;
                string State = txt_State.Text;
                string country = txt_country.Text;
                string pincode = txt_pincode.Text;
                string date = dtp_date.Text;
                string email = txt_email.Text;
                string phone = txt_phone.Text;
                string desc = txt_description.Text;
                string gstno = txt_vattinno.Text;
                string licno = txt_cstno.Text;


                

                string message = cc.Vendor(vendorname, address, city, State, country, pincode, date, email, phone, desc, gstno, licno);
                MessageBox.Show(message);

                cc.Log(Mainform.username, "Upload", "VendorDetails", DateTime.Now.ToString());
            }
            catch { }
        }

        private void btnRetrieve_Click(object sender, EventArgs e)
        {
            try
            {
                blockchain.BlockChain cc = new blockchain.BlockChain();
                string[] res = cc.Getvendor().ToString().Split('~');

                datagridview1.Rows.Clear();

                for (int i = 0; i < res.Length; i++)
                {
                    if (res[i] == "") { }
                    else
                    {
                        string[] data = res[i].ToString().Split(',');
                        datagridview1.Rows.Add();
                        for (int j = 0; j < data.Length; j++)
                        {
                            datagridview1.Rows[i].Cells[j].Value = data[j].ToString();
                        }
                    }

                }
            }
            catch { }

            try
            {
                cc.Log(Mainform.username, "Retrieve", "VendorDetails", DateTime.Now.ToString());
            }
            catch { }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VendorDetails_Load(object sender, EventArgs e)
        {

            if (Mainform.adminflg == 1)
            {
                btnRetrieve_Click(null, null);
            }
            else
            {

                btnsave.Visible = false;
                btnRetrieve.Visible = false;

                try
                {
                    //blockchain.BlockChain cc = new blockchain.BlockChain();
                    //string result = cc.GetAuthentication("Vendor", Mainform.username);

                    //string[] data = result.ToString().Split(',');

                     int flg = 0;
                    List<string> udetails = new List<string>();                

                    if (File.Exists(Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt"))
                    {
                        flg = 1;
                    }

                    if (flg > 0)
                    {
                        string files = Application.StartupPath + "\\BlockHeader\\" + Mainform.username + ".txt";
                        StreamReader sr = new StreamReader(files);
                        string[] data1 = sr.ReadToEnd().ToString().Split('~');
                        sr.Close();

                        AES a = new AES("00");
                        for (int i = 0; i < data1.Length; i++)
                        {
                            string textt = a.Decrypt_CBC(data1[i].ToString());
                            udetails.Add(textt);
                        }


                        udetails[5] = udetails[5].Replace("Vendor Permission : ", "");
                        string[] data = udetails[5].ToString().Split(',');

                        if (data.Length == 1)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[0].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }

                        }

                        else if (data.Length == 2)
                        {
                            if (data[0].ToString() == "Upload")
                            {
                                btnsave.Visible = true;
                            }

                            if (data[1].ToString() == "Retrieve")
                            {
                                btnRetrieve.Visible = true;
                            }

                        }
                    }
                    else
                    {
                        MessageBox.Show("Block Not Present");
                    }
                }
                catch { }
            }
        }
    }
}
