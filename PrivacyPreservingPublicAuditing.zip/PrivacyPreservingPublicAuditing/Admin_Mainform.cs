﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrivacyPreservingPublicAuditing
{
    public partial class Admin_Mainform : Form
    {
        public Admin_Mainform()
        {
            InitializeComponent();
        }

        private void userDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Mainform.adminname == "admin 1")
            {
                panel2.Controls.Clear();
                UserDetails r = new UserDetails();
                r.TopLevel = false;
                r.Dock = DockStyle.Fill;
                r.FormBorderStyle = FormBorderStyle.None;
                r.WindowState = FormWindowState.Maximized;
                this.panel2.Controls.Add(r);
                r.Show();
                Mainform.adminname = "";
            }
            else if (Mainform.adminname == "admin 2")
            {
                panel2.Controls.Clear();
                Admin2Approve r = new Admin2Approve();
                r.TopLevel = false;
                r.Dock = DockStyle.Fill;
                r.FormBorderStyle = FormBorderStyle.None;
                r.WindowState = FormWindowState.Maximized;
                this.panel2.Controls.Add(r);
                r.Show();
                Mainform.adminname = "";
            }
            else if (Mainform.adminname == "admin 3")
            {
                panel2.Controls.Clear();
                Admin3Approve r = new Admin3Approve();
                r.TopLevel = false;
                r.Dock = DockStyle.Fill;
                r.FormBorderStyle = FormBorderStyle.None;
                r.WindowState = FormWindowState.Maximized;
                this.panel2.Controls.Add(r);
                r.Show();
                Mainform.adminname="";
            }
        }

        private void authenticationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Authentication r = new Authentication();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void admin1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void admin2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void admin3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void blockHeaderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            BlockHeader r = new BlockHeader();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void uploadFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            AdminUpload r = new AdminUpload();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void employeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            FrmEmployees r = new FrmEmployees();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Customer r = new Customer();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void purchaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Purchase r = new Purchase();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void vendorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            VendorDetails r = new VendorDetails();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Mainform.adminflg = 0;
            Mainform.adminflg = 0;
            Application.Exit();

            Mainform m = new Mainform();
            m.Show();

        }

        private void Admin_Mainform_FormClosing(object sender, FormClosingEventArgs e)
        {
            Mainform.adminflg = 0;

            Mainform.adminflg = 0;

            Mainform m = new Mainform();
            m.Show();
        }

        private void Admin_Mainform_FormClosed(object sender, FormClosedEventArgs e)
        {
            Mainform.adminflg = 0;
            Mainform.adminflg = 0;

            Mainform m = new Mainform();
            m.Show();
        }

        private void displayLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            DisplayLog r = new DisplayLog();
            r.TopLevel = false;
            r.Dock = DockStyle.Fill;
            r.FormBorderStyle = FormBorderStyle.None;
            r.WindowState = FormWindowState.Maximized;
            this.panel2.Controls.Add(r);
            r.Show();
        }
    }
}
