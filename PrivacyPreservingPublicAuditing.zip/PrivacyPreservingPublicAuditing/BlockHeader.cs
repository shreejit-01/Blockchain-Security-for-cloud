﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PrivacyPreservingPublicAuditing
{
    public partial class BlockHeader : Form
    {
        AES aa = new AES("00");
        blockchain.BlockChain cc = new blockchain.BlockChain();
        public BlockHeader()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string[] uname = cc.UserList().Split('~');
                for (int i = 0; i < uname.Length; i++)
                {
                    StreamWriter sw = new StreamWriter(Application.StartupPath + "\\BlockHeader\\"+ uname[i].ToString() +".txt");
                    string encryptdata = "";
                    string[] data = cc.GenerateBlockHeader(uname[i].ToString()).Split('~');

                    for (int j = 0; j < data.Length; j++)
                    {
                        string encrypt = aa.Encrypt_CBC(data[j].ToString());

                        if (j == 0)
                        {
                            encryptdata = encrypt.ToString();
                        }
                        else
                        {
                            encryptdata += "~" + encrypt.ToString();
                        }
                    }
                    sw.WriteLine(encryptdata);
                    sw.Close();                  
                }                   
            }
            catch { }
        }
    }
}
